ITEM.name = "Suitcase"
ITEM.description = "A small suitcase."
ITEM.model = Model("models/weapons/w_suitcase_passenger.mdl")